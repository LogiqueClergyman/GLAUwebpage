import React from 'react'
import '../Foot_css.css'

export default function Footer() {
  return (
    <div>
        <div class="footer">
   
   <div class="box-container">

       <div class="box">
           <h2>GLA University</h2>
           <p> <i class="fas fa-map-marker-alt"></i><a href="https://www.google.com/maps/search/gla+university+location/@27.6465074,77.5596851,13z/data=!3m1!4b1" target="blank">
               17 KM Stone,NH#2, Mathura-Delhi Road<br></br>
               UttarPradesh (281 406)
           </a></p>
           <p><i class="fas fa-phone"></i> 09534-625894</p>

       </div>

       <div class="box">
           <h3>Our Campus</h3>
           <a href="#home">Gallary</a>
           <a href="#about">Guest House</a>
           <a href="#menu">Health Care</a>
           <a href="#popular">Library</a>
           <a href="#gallery">STEP</a>
           <a href="#gallery">Virtual Tour</a>
       </div>

       <div class="box">
           <h3>quick links </h3>
           <a href="#home">TEQIP</a>
           <a href="#about">Career Development</a>
           <a href="#menu">Department</a>
           <a href="#popular">Intranet</a>
           <a href="#gallery">IRIS Portal</a>

       </div>

       <div class="box">
           <h3>follow us</h3>
           <a href="https://www.instagram.com/glauniv/?hl=en" target="_blank">instagram</a>
           <a href="https://www.facebook.com/people/Nandani-Masala/100063522382588/" target="_blank">facebook</a>
           <a href="https://twitter.com/MasalaNandani?s=09" target="_blank">twitter</a>

       </div>

   </div>

   <h1 class="credit">  Copyright All rights reserved 2022,</h1>

</div>


    </div>
  )
}
